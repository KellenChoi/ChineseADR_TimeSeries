#Install and Load all necessary packages
library(quantmod)
library(xts)
library(TTR)
library(tseries)
library(moments)
library(fitdistrplus)
library(goftest)

setwd("C:/Users/Sam/Desktop/Rengs/Coding Stuff/R/For Time Series/Project/Data")
#Step 1 of n - Getting Data
#1 -> Only 2018 data - not useful
getSymbols("CBUMY", src="yahoo", from="2013-01-01", to="2018-01-31")
write.csv(CBUMY, "China National Building.csv", na = "NA")

#2 -> Good Data; No NAs
getSymbols("CWYCY", src="yahoo", from="2013-01-01", to="2018-01-31")
write.csv(CWYCY, "China Railway Constructruction.csv", na = "NA")

#3 -> Good Data; No NAs
getSymbols("CSUAY", src="yahoo", from="2013-01-01", to="2018-01-31")
write.csv(CSUAY, "China Shenhua Energy.csv", na = "NA")

#4 -> Good Data; No NAs
getSymbols("CCOHY", src="yahoo", from="2013-01-01", to="2018-01-31")
write.csv(CCOHY, "China State Construction.csv", na = "NA")

#5 -> Good Data; No NAs - But HK ticker not available?
getSymbols("CSUNY", src="yahoo", from="2013-01-01", to="2018-01-31")
write.csv(CSUNY, "China Sunergy.csv", na = "NA")

#6 -> Not very Good Data; but no NAs
getSymbols("CICOY", src="yahoo", from="2013-01-01", to="2018-01-31")
write.csv(CICOY, "Cosco Shipping Holdings.csv", na = "NA")

#7 -> Good Data; no NAs
getSymbols("DNFGY", src="yahoo", from="2013-01-01", to="2018-01-31")
write.csv(DNFGY, "Dongfeng Motor.csv", na = "NA")

#8 -> 4 years data (from 2014); No NAs
getSymbols("XNGSY", src="yahoo", from="2013-01-01", to="2018-01-31")
write.csv(XNGSY, "ENN Energy.csv", na = "NA")


#Plot CSUNY Closing Price, Simple Returns, Log Returns
CSUNY_close = CSUNY$CSUNY.Close
plot(CSUNY_close, main = "CSUNY Close Prices")
CSUNY_SReturns = Delt(CSUNY_close, type = "arithmetic")[-1]
lines(CSUNY_SReturns, type = "h", on = NA)
CSUNY_LReturns = Delt(CSUNY_close, type = "log")[-1]
lines(CSUNY_LReturns, type = "h", on = NA)

#Step 2 of n - Coverting Data to Time Series format - Not required here since using Quantmod automatically gives XTS objects
#Creating TS of Log returns (based on Closing Prices)
#CSUNY_Data = data.frame(CSUNY$CSUNY.Close[-1])
#CSUNY_Data$LReturns <- CSUNY_LReturns
#CSUNY_TS_LReturns = as.xts(CSUNY_Data$LReturns)
#chartSeries(CSUNY_TS_LReturns, theme="white", TA=NULL, type='line', name ='CSUNY Log Returns TS')

#Step 3 of n - Normality Tests
#Converting Log Returns TS to Numeric Vector
CSUNY_LReturns_Normal <- as.numeric(CSUNY_LReturns)

#Checking Normality by Value
summary(CSUNY_LReturns_Normal)
mean(CSUNY_LReturns_Normal)
var(CSUNY_LReturns_Normal)
skewness(CSUNY_LReturns_Normal)
kurtosis(CSUNY_LReturns_Normal)

#Checking Normality by Visual Inspection
LReturns_fit1 <- fitdist(CSUNY_LReturns_Normal, "norm")
plot(LReturns_fit1)
gofstat(LReturns_fit1)
#Not Quite Normal

#Checking Normality by Standard Tests
shapiro.test(CSUNY_LReturns_Normal)
#Not Quite Normal

#Step 4 of n - Stationarity Tests
#Testing if the TS of Log returns is Stationary
chart_Series(CSUNY_LReturns)
adf.test(CSUNY_LReturns)
kpss.test(CSUNY_LReturns)

#Closing prices say Non-stationary; Simple and Log returns are stationary

#Step 5 of n - Checking Serial Correlation
#Testing if the TS of Log returns has Serial Correlation
acf(CSUNY_TS_LReturns)
Box.test(CSUNY_TS_LReturns)

#There is no serial Correlation of Log Returns

#Step 6 of n - Checking with AR(1) Model
a1 <- 0.8 #Assumption
x <- w <- CSUNY_TS_LReturns
for (t in length(CSUNY_TS_LReturns_Normal)) x[t] <- a1*x[t-1] + w[t]
plot(x, type="l", xlab='Time')
plot(density(x))
wilcox.test(x)
adf.test(x) #-stationary
kpss.test(x)
# Plot the correlogram of the AR(1) process
acf(x)
Box.test(x) #- strong serial correlation !!!!
x <- as.numeric(x)
AR1_LReturns_fit1 <- fitdist(x, "norm")
plot(AR1_LReturns_fit1)

AR1_LReturns_fit2 <- fitdist(diff(x), "norm")
plot(AR1_LReturns_fit2)
