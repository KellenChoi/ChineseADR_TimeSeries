#Install and Load all necessary packages
library(quantmod)
library(xts)
library(TTR)
library(tseries)
library(fitdistrplus)
library(goftest)
library(moments)
library(metRology)
setwd("C:/Users/Sam/Desktop/Rengs/Coding Stuff/R/For Time Series/Project/Data")

#Step 1 - Getting Data
#1.1 HK Data - Source Yahoo - CICOY, 1919.HK
getSymbols("1919.HK", src="yahoo", from="2013-01-01", to="2018-01-31")
CICOY_HK <- as.xts(`1919.HK`)
write.csv(CICOY_HK, "1-Cosco Shipping.csv", na = "NA")

date_index_1 <- index(CICOY_HK)
#Date index for this stock in Hong Kong Stock Exchange
sum(is.na(CICOY_HK))
#Some NAs in the data
chart_Series(CICOY_HK$`1919.HK.Close`)
#Visual
max(CICOY_HK$`1919.HK.Close`)
min(CICOY_HK$`1919.HK.Close`)
nrow(CICOY_HK)

#1.2 ADR Data - Source Yahoo
getSymbols("CICOY", src="yahoo", from="2013-01-01", to="2018-01-31")
CICOY_ADR <- as.xts(CICOY)
write.csv(CICOY_ADR, "2-Cosco Shipping.csv", na = "NA")

date_index_2 <- index(CICOY_ADR)
#Date index for this stock in ADR
sum(is.na(CICOY_ADR))
#No NAs in the data
chart_Series(CICOY_ADR$CICOY.Close)
#Visual

max(CICOY_ADR$CICOY.Open)
min(CICOY_ADR$CICOY.Open)
nrow(CICOY_ADR)
#Step 2 - Statistical Analysis specific to this stock

#2.1 Analysis on HK part

#2.1.1 - Stationarity Test
adf.test(CICOY_HK$`1919.HK.Close`)
kpss.test(CICOY_HK$`1919.HK.Close`)
#Price ofcourse is non stationary - Hence move on to log returns

CICOY_HK_LogReturns <- Delt(CICOY_HK$`1919.HK.Close`, type = "log")[-1]
chartSeries(CICOY_HK_LogReturns)
adf.test(CICOY_HK_LogReturns)
kpss.test(CICOY_HK_LogReturns)

#2.1.2 - Normality Test

CICOY_HK_LogReturns_Numeric <- as.numeric(CICOY_HK_LogReturns)

#By Visual Inspection
LogReturns_fit1 <- fitdist(CICOY_HK_LogReturns_Numeric, "norm")
plot(LogReturns_fit1)

#By Values
skewness(CICOY_HK_LogReturns_Numeric)
kurtosis(CICOY_HK_LogReturns_Numeric)

#By standard tests
shapiro.test(CICOY_HK_LogReturns_Numeric)
ad.test(CICOY_HK_LogReturns_Numeric, null = "pnorm")
#Not normal

LogReturns_fit1 <- fitdist(CICOY_HK_LogReturns_Numeric,"t.scaled", start=list(df=3,mean=mean(CICOY_HK_LogReturns_Numeric),sd=sd(CICOY_HK_LogReturns_Numeric)))
plot(LogReturns_fit1, histo = FALSE, demp = TRUE)
LogReturns_fit1$estimate
#Fits better with student-t distribution of DF = 4

#2.1.3 - Autocorrelation
acf(CICOY_HK_LogReturns)
#Hint of 0 MA degrees
Box.test(CICOY_HK_LogReturns)
pacf(CICOY_HK_LogReturns)
#Hint of 2 AR degress
final_aic <- Inf
final_order <- c(0,0,0)
CICOY_HK_Final <- arima(CICOY_HK_LogReturns, order = final_order)

for (i in 0:5) {
  for (j in 0:5) {
    current_order <- c(i, 0, j)
    CICOY_HK_Current <- arima(CICOY_HK_LogReturns, order = current_order)
    current_aic <- AIC(CICOY_HK_Current)
    if (current_aic < final_aic) {
      final_aic <- current_aic
      final_order <- c(i, 0, j)
      CICOY_HK_Final <- arima(CICOY_HK_LogReturns, order = final_order)
    }
  }
}
AIC(CICOY_HK_Final)
final_order
acf(resid(CICOY_HK_Final), na.action=na.omit)

#2.2 Analysis on ADR part
#2.2.1 - Stationarity Test
adf.test(CICOY_ADR$CICOY.Open)
kpss.test(CICOY_ADR$CICOY.Open)
#Price ofcourse is non stationary - Hence move on to log returns

CICOY_ADR_LogReturns <- Delt(CICOY_ADR$CICOY.Open, type = "log")[-1]
chartSeries(CICOY_ADR_LogReturns)
adf.test(CICOY_ADR_LogReturns)
kpss.test(CICOY_ADR_LogReturns)

#2.2.2 - Normality Test

CICOY_ADR_LogReturns_Numeric <- as.numeric(CICOY_ADR_LogReturns)

#By Visual Inspection
LogReturns_fit2 <- fitdist(CICOY_ADR_LogReturns_Numeric, "norm")
plot(LogReturns_fit1)

#By Values
skewness(CICOY_ADR_LogReturns_Numeric)
kurtosis(CICOY_ADR_LogReturns_Numeric)

#By standard tests
shapiro.test(CICOY_ADR_LogReturns_Numeric)
ad.test(CICOY_ADR_LogReturns_Numeric, null = "pnorm")
#Not normal

LogReturns_fit2 <- fitdist(CICOY_ADR_LogReturns_Numeric,"t.scaled", start=list(df=6,mean=mean(CICOY_ADR_LogReturns_Numeric),sd=sd(CICOY_ADR_LogReturns_Numeric)))
plot(LogReturns_fit2, histo = FALSE, demp = TRUE)
LogReturns_fit2$estimate
#Fits with student-t distribution

#2.2.3 - Autocorrelation
acf(CICOY_ADR_LogReturns)
#Hint of 2 or 3 MA degrees
Box.test(CICOY_ADR_LogReturns)
pacf(CICOY_ADR_LogReturns)
#Hint of 1 or 2 AR degress

final_aic <- Inf
final_order <- c(0,0,0)
CICOY_ADR_Final <- arima(CICOY_ADR_LogReturns, order = final_order)

for (i in 0:5) {
  for (j in 0:5) {
    current_order <- c(i, 0, j)
    CICOY_ADR_Current <- arima(CICOY_ADR_LogReturns, order = current_order)
    current_aic <- AIC(CICOY_ADR_Current)
    if (current_aic < final_aic) {
      final_aic <- current_aic
      final_order <- c(i, 0, j)
      CICOY_ADR_Final <- arima(CICOY_ADR_LogReturns, order = final_order)
    }
  }
}
AIC(CICOY_ADR_Final)
final_order
acf(resid(CICOY_ADR_Final), na.action=na.omit)

#Summary of the Analysis - possibly arrive at a common ARMA Model for Returns on both exchanges

#Step 3 - Matching the Dates and Forming the two Time Series Data to see co-movements
#3.1 - Method one - Filling the holidays with respective previous daya's prices in both Markets
date_index_union <- as.Date(union(date_index_1, date_index_2))

a <- length(date_index_union)
HK_close <- rep(1, a)
ADR_Open <- rep(1, a)
data_combined <- data.frame(date_index_union, HK_close, ADR_Open)

dummy_dateindex_1 <- match(date_index_union, date_index_1)
dummy_dateindex_2 <- match(date_index_union, date_index_2)
temporary_index <- data_combined$date_index_union


for(i in 1:a){
  if(!is.na(dummy_dateindex_1[i])) {
    data_combined$HK_close[i] = CICOY_HK$`1919.HK.Close`[index(CICOY_HK) %in% temporary_index[i]]
  }
  
  if(!is.na(dummy_dateindex_2[i])) {
    data_combined$ADR_Open[i] = CICOY_ADR$CICOY.Open[index(CICOY_ADR) %in% temporary_index[i]]
  }
}

for(i in 1:a){
  if(data_combined$HK_close[i] == 1) {
    data_combined$HK_close[i] = data_combined$HK_close[i-1]
  }
  
  if(data_combined$ADR_Open[i] == 1) {
    data_combined$ADR_Open[i] = data_combined$ADR_Open[i-1]
  }
}

CICOY_TS <- as.xts(data_combined[,-1], order.by = data_combined$date_index_union)
CICOY_TS1_LogReturns <- Delt(CICOY_TS$HK_close, type = "log")[-1]
CICOY_TS2_LogReturns <- Delt(CICOY_TS$ADR_Open, type = "log")[-1]
ccf(as.numeric(CICOY_TS1_LogReturns),as.numeric(CICOY_TS2_LogReturns))

plot(as.numeric(CICOY_TS1_LogReturns),as.numeric(CICOY_TS2_LogReturns))
regression1 <- lm(CICOY_TS2_LogReturns~CICOY_TS1_LogReturns)
summary(regression1)
#No sufficient Linear Correlation observed - What is the next step?

#3.2 - Method two - Dropping the holidays and mismatching dates in the two Markets altogether
date_index_intersection <- as.Date(intersect(date_index_1, date_index_2))

b <- length(date_index_intersection)
HK_close <- rep(1, b)
ADR_Open <- rep(1, b)
data_combined <- data.frame(date_index_intersection, HK_close, ADR_Open)

dummy_dateindex_1 <- match(date_index_intersection, date_index_1)
dummy_dateindex_2 <- match(date_index_intersection, date_index_2)
temporary_index <- data_combined$date_index_intersection


for(i in 1:a){
  if(!is.na(dummy_dateindex_1[i])) {
    data_combined$HK_close[i] = CICOY_HK$`1919.HK.Close`[index(CICOY_HK) %in% temporary_index[i]]
  }
  
  if(!is.na(dummy_dateindex_2[i])) {
    data_combined$ADR_Open[i] = CICOY_ADR$CICOY.Open[index(CICOY_ADR) %in% temporary_index[i]]
  }
}

CICOY_TS <- as.xts(data_combined[,-1], order.by = data_combined$date_index_intersection)
CICOY_TS1_LogReturns <- Delt(CICOY_TS$HK_close, type = "log")[-1]
CICOY_TS2_LogReturns <- Delt(CICOY_TS$ADR_Open, type = "log")[-1]
ccf(as.numeric(CICOY_TS1_LogReturns),as.numeric(CICOY_TS2_LogReturns))

plot(as.numeric(CICOY_TS1_LogReturns),as.numeric(CICOY_TS2_LogReturns))
regression1 <- lm(CICOY_TS2_LogReturns~CICOY_TS1_LogReturns)
summary(regression1)