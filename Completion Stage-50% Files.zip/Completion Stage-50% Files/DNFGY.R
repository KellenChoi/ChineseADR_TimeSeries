#Install and Load all necessary packages
library(quantmod)
library(xts)
library(TTR)
library(tseries)
library(fitdistrplus)
library(goftest)
library(moments)
library(metRology)
setwd("C:/Users/Sam/Desktop/Rengs/Coding Stuff/R/For Time Series/Project/Data")

#Step 1 - Getting Data
#1.1 HK Data - Source Yahoo - DNFGY, 0489.HK
getSymbols("0489.HK", src="yahoo", from="2013-01-01", to="2018-01-31")
DNFGY_HK <- as.xts(`0489.HK`)
write.csv(DNFGY_HK, "1-Dongfeng Motor.csv", na = "NA")

date_index_1 <- index(DNFGY_HK)
#Date index for this stock in Hong Kong Stock Exchange
sum(is.na(DNFGY_HK))
#Some NAs in the data
chart_Series(DNFGY_HK$`0489.HK.Close`)
#Visual
max(DNFGY_HK$`0489.HK.Close`)
min(DNFGY_HK$`0489.HK.Close`)
nrow(DNFGY_HK)

#1.2 ADR Data - Source Yahoo
getSymbols("DNFGY", src="yahoo", from="2013-01-01", to="2018-01-31")
DNFGY_ADR <- as.xts(DNFGY)
write.csv(DNFGY_ADR, "2-Dongfeng Motor.csv", na = "NA")

date_index_2 <- index(DNFGY_ADR)
#Date index for this stock in ADR
sum(is.na(DNFGY_ADR))
#No NAs in the data
chart_Series(DNFGY_ADR$DNFGY.Close)
#Visual

max(DNFGY_ADR$DNFGY.Open)
min(DNFGY_ADR$DNFGY.Open)
nrow(DNFGY_ADR)
#Step 2 - Statistical Analysis specific to this stock

#2.1 Analysis on HK part

#2.1.1 - Stationarity Test
adf.test(DNFGY_HK$`0489.HK.Close`)
kpss.test(DNFGY_HK$`0489.HK.Close`)
#Price ofcourse is non stationary - Hence move on to log returns

DNFGY_HK_LogReturns <- Delt(DNFGY_HK$`0489.HK.Close`, type = "log")[-1]
chartSeries(DNFGY_HK_LogReturns)
adf.test(DNFGY_HK_LogReturns)
kpss.test(DNFGY_HK_LogReturns)

#2.1.2 - Normality Test

DNFGY_HK_LogReturns_Numeric <- as.numeric(DNFGY_HK_LogReturns)

#By Visual Inspection
LogReturns_fit1 <- fitdist(DNFGY_HK_LogReturns_Numeric, "norm")
plot(LogReturns_fit1)

#By Values
skewness(DNFGY_HK_LogReturns_Numeric)
kurtosis(DNFGY_HK_LogReturns_Numeric)

#By standard tests
shapiro.test(DNFGY_HK_LogReturns_Numeric)
ad.test(DNFGY_HK_LogReturns_Numeric, null = "pnorm")
#Not normal

LogReturns_fit1 <- fitdist(DNFGY_HK_LogReturns_Numeric,"t.scaled", start=list(df=3,mean=mean(DNFGY_HK_LogReturns_Numeric),sd=sd(DNFGY_HK_LogReturns_Numeric)))
plot(LogReturns_fit1, histo = FALSE, demp = TRUE)
LogReturns_fit1$estimate
#Fits better with student-t distribution of DF = 4

#2.1.3 - Autocorrelation
acf(DNFGY_HK_LogReturns)
#Hint of 0 MA degrees
Box.test(DNFGY_HK_LogReturns)
pacf(DNFGY_HK_LogReturns)
#Hint of 2 AR degress
final_aic <- Inf
final_order <- c(0,0,0)
DNFGY_HK_Final <- arima(DNFGY_HK_LogReturns, order = final_order)

for (i in 0:5) {
  for (j in 0:5) {
    current_order <- c(i, 0, j)
    DNFGY_HK_Current <- arima(DNFGY_HK_LogReturns, order = current_order)
    current_aic <- AIC(DNFGY_HK_Current)
    if (current_aic < final_aic) {
      final_aic <- current_aic
      final_order <- c(i, 0, j)
      DNFGY_HK_Final <- arima(DNFGY_HK_LogReturns, order = final_order)
    }
  }
}
AIC(DNFGY_HK_Final)
final_order
acf(resid(DNFGY_HK_Final), na.action=na.omit)

#2.2 Analysis on ADR part
#2.2.1 - Stationarity Test
adf.test(DNFGY_ADR$DNFGY.Open)
kpss.test(DNFGY_ADR$DNFGY.Open)
#Price ofcourse is non stationary - Hence move on to log returns

DNFGY_ADR_LogReturns <- Delt(DNFGY_ADR$DNFGY.Open, type = "log")[-1]
chartSeries(DNFGY_ADR_LogReturns)
adf.test(DNFGY_ADR_LogReturns)
kpss.test(DNFGY_ADR_LogReturns)

#2.2.2 - Normality Test

DNFGY_ADR_LogReturns_Numeric <- as.numeric(DNFGY_ADR_LogReturns)

#By Visual Inspection
LogReturns_fit2 <- fitdist(DNFGY_ADR_LogReturns_Numeric, "norm")
plot(LogReturns_fit1)

#By Values
skewness(DNFGY_ADR_LogReturns_Numeric)
kurtosis(DNFGY_ADR_LogReturns_Numeric)

#By standard tests
shapiro.test(DNFGY_ADR_LogReturns_Numeric)
ad.test(DNFGY_ADR_LogReturns_Numeric, null = "pnorm")
#Not normal

LogReturns_fit2 <- fitdist(DNFGY_ADR_LogReturns_Numeric,"t.scaled", start=list(df=6,mean=mean(DNFGY_ADR_LogReturns_Numeric),sd=sd(DNFGY_ADR_LogReturns_Numeric)))
plot(LogReturns_fit2, histo = FALSE, demp = TRUE)
LogReturns_fit2$estimate
#Fits with student-t distribution

#2.2.3 - Autocorrelation
acf(DNFGY_ADR_LogReturns)
#Hint of 2 or 3 MA degrees
Box.test(DNFGY_ADR_LogReturns)
pacf(DNFGY_ADR_LogReturns)
#Hint of 1 or 2 AR degress

final_aic <- Inf
final_order <- c(0,0,0)
DNFGY_ADR_Final <- arima(DNFGY_ADR_LogReturns, order = final_order)

for (i in 0:5) {
  for (j in 0:5) {
    current_order <- c(i, 0, j)
    DNFGY_ADR_Current <- arima(DNFGY_ADR_LogReturns, order = current_order)
    current_aic <- AIC(DNFGY_ADR_Current)
    if (current_aic < final_aic) {
      final_aic <- current_aic
      final_order <- c(i, 0, j)
      DNFGY_ADR_Final <- arima(DNFGY_ADR_LogReturns, order = final_order)
    }
  }
}
AIC(DNFGY_ADR_Final)
final_order
acf(resid(DNFGY_ADR_Final), na.action=na.omit)

#Summary of the Analysis - possibly arrive at a common ARMA Model for Returns on both exchanges

#Step 3 - Matching the Dates and Forming the two Time Series Data to see co-movements
#3.1 - Method one - Filling the holidays with respective previous daya's prices in both Markets
date_index_union <- as.Date(union(date_index_1, date_index_2))

a <- length(date_index_union)
HK_close <- rep(1, a)
ADR_Open <- rep(1, a)
data_combined <- data.frame(date_index_union, HK_close, ADR_Open)

dummy_dateindex_1 <- match(date_index_union, date_index_1)
dummy_dateindex_2 <- match(date_index_union, date_index_2)
temporary_index <- data_combined$date_index_union


for(i in 1:a){
  if(!is.na(dummy_dateindex_1[i])) {
    data_combined$HK_close[i] = DNFGY_HK$`0489.HK.Close`[index(DNFGY_HK) %in% temporary_index[i]]
  }
  
  if(!is.na(dummy_dateindex_2[i])) {
    data_combined$ADR_Open[i] = DNFGY_ADR$DNFGY.Open[index(DNFGY_ADR) %in% temporary_index[i]]
  }
}

for(i in 1:a){
  if(data_combined$HK_close[i] == 1) {
    data_combined$HK_close[i] = data_combined$HK_close[i-1]
  }
  
  if(data_combined$ADR_Open[i] == 1) {
    data_combined$ADR_Open[i] = data_combined$ADR_Open[i-1]
  }
}

DNFGY_TS <- as.xts(data_combined[,-1], order.by = data_combined$date_index_union)
DNFGY_TS1_LogReturns <- Delt(DNFGY_TS$HK_close, type = "log")[-1]
DNFGY_TS2_LogReturns <- Delt(DNFGY_TS$ADR_Open, type = "log")[-1]
ccf(as.numeric(DNFGY_TS1_LogReturns),as.numeric(DNFGY_TS2_LogReturns))

plot(as.numeric(DNFGY_TS1_LogReturns),as.numeric(DNFGY_TS2_LogReturns))
regression1 <- lm(DNFGY_TS2_LogReturns~DNFGY_TS1_LogReturns)
summary(regression1)
#No sufficient Linear Correlation observed - What is the next step?

#3.2 - Method two - Dropping the holidays and mismatching dates in the two Markets altogether
date_index_intersection <- as.Date(intersect(date_index_1, date_index_2))

b <- length(date_index_intersection)
HK_close <- rep(1, b)
ADR_Open <- rep(1, b)
data_combined <- data.frame(date_index_intersection, HK_close, ADR_Open)

dummy_dateindex_1 <- match(date_index_intersection, date_index_1)
dummy_dateindex_2 <- match(date_index_intersection, date_index_2)
temporary_index <- data_combined$date_index_intersection


for(i in 1:a){
  if(!is.na(dummy_dateindex_1[i])) {
    data_combined$HK_close[i] = DNFGY_HK$`0489.HK.Close`[index(DNFGY_HK) %in% temporary_index[i]]
  }
  
  if(!is.na(dummy_dateindex_2[i])) {
    data_combined$ADR_Open[i] = DNFGY_ADR$DNFGY.Open[index(DNFGY_ADR) %in% temporary_index[i]]
  }
}

DNFGY_TS <- as.xts(data_combined[,-1], order.by = data_combined$date_index_intersection)
DNFGY_TS1_LogReturns <- Delt(DNFGY_TS$HK_close, type = "log")[-1]
DNFGY_TS2_LogReturns <- Delt(DNFGY_TS$ADR_Open, type = "log")[-1]
ccf(as.numeric(DNFGY_TS1_LogReturns),as.numeric(DNFGY_TS2_LogReturns))

plot(as.numeric(DNFGY_TS1_LogReturns),as.numeric(DNFGY_TS2_LogReturns))
regression1 <- lm(DNFGY_TS2_LogReturns~DNFGY_TS1_LogReturns)
summary(regression1)