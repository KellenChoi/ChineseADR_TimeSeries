#is_Stationary function
#Takes a Time Series and an integer indicating nth call of the function - for file saving purposes
#Returns the p-value of the ADF and KPSS tests for stationarity

is_Stationary <- function(LogReturns_TS, i)
{
  jpeg(filename = paste("Stationarity-", i, "-.jpeg", sep = ""))
  chartSeries(LogReturns_TS, name = "Plot of Log Returns")
  dev.off()
  adf_test <- adf.test(LogReturns_TS)
  kpss_test <- kpss.test(LogReturns_TS)
  return(list(adf_test$p.value, kpss_test$p.value))
}

#is_Normal function
#Takes a Numeric object and an integer indicating nth call of the function - for file saving purposes
#Returns the p-value of the Shapiro test for Normality
is_Normal <- function(LogReturns_NumericTS, i) 
{
  LogReturns_fit <- fitdist(LogReturns_NumericTS, "norm")
  jpeg(filename = paste("Normality-", i, "-.jpeg", sep = ""))
  plot(LogReturns_fit)
  dev.off()
  
  shapiro_test <- shapiro.test(LogReturns_NumericTS)
  return(shapiro_test$p.value)
}

#Manual ARIMA

find_ARIMA_order <- function(LogReturns_TS) {
  final_aic <- Inf
  final_order <- c(0,0,0)
  require(stats)
  
  Fitted_ARIMA <- arima(LogReturns_TS, order = final_order)
  
  for (i in 0:5) {
    for (j in 0:5) {
      current_order <- c(i, 0, j)
      Fitted_ARIMA <- arima(LogReturns_TS, order = current_order)
      current_aic <- AIC(Fitted_ARIMA)
      
      if (current_aic < final_aic) {
        final_aic <- current_aic
        final_order <- c(i, 0, j)
        Fitted_ARIMA <- arima(LogReturns_TS, order = final_order)
      }
    }
  }
  return(final_order)
}

