#Install and Load all necessary packages
library(quantmod)
library(xts)
library(TTR)
library(tseries)
library(fitdistrplus)
library(goftest)
library(moments)
library(metRology)
library(dplyr)
library(forecast)
library(timeSeries)
library(ggplot2)


#Set working directory specific to your local system
setwd("C:/Users/Sam/Desktop/Rengs/Coding Stuff/R/For Time Series/Project/Data2")

#Step 1.1 - Getting Data

#Change the relevant stock tickers, source and dates here
Ticker_HK <- "2018.HK"
Ticker_ADR <- "AACAY"
Index_HK <- "^HSI"
Data_Source <- "yahoo"
Sample_Date_From <- "2013-01-01"
Sample_Date_To <- "2018-04-01"
alpha <- 0.05 #acceptance level for statistical tests
Test_Days <- 120

HK_TS <- getSymbols(Ticker_HK, src = Data_Source, from = Sample_Date_From, to = Sample_Date_To, auto.assign = FALSE)
ADR_TS <- getSymbols(Ticker_ADR, src = Data_Source, from = Sample_Date_From, to = Sample_Date_To, auto.assign = FALSE)
Index_HK_TS <- getSymbols(Index_HK, src = Data_Source, from = Sample_Date_From, to = Sample_Date_To, auto.assign = FALSE)

#Step 1.2 - Preliminary view of the data
#Check for missing values and a simple price movement view (HK Closing & ADR Opening)
sum(is.na(HK_TS))
sum(is.na(ADR_TS))
sum(is.na(Index_HK_TS)) #NA values are to be taken care specifically
Index_HK_TS <- na.omit(Index_HK_TS)
sum(is.na(Index_HK_TS))
nrow(HK_TS)
nrow(ADR_TS)
nrow(Index_HK_TS)
Index_HK_TS <- na.omit(Index_HK_TS)

#Saving the plots for reporting - change the file name as needed
jpeg(filename = "Price Movement-Overview.jpeg")
chart_Series(HK_TS$`2018.HK.Close`, type = "lines", name = "Price Movement Overview")
add_TA(Index_HK_TS$HSI.Close)
add_TA(ADR_TS$AACAY.Open)
dev.off()

#------------------------------------------------------------------------------------------

#Step 2 - Matching the timeline of the three TS
Dateindex_HKTS <- index(HK_TS)
Dateindex_ADRTS <- index(ADR_TS)
Dateindex_HKIndex <- index(Index_HK_TS)

Dateindex_intersection <- as.Date(Reduce(intersect, list(Dateindex_ADRTS, Dateindex_HKIndex, Dateindex_HKTS)))

#Data Cleansing - Matching the timescale on the 3 Timeseries
b <- length(Dateindex_intersection)
HK_Close <- rep(1, b)
ADR_Open <- rep(1, b)
Index_Close <- rep(1, b)
Data_Filtered <- data.frame(Dateindex_intersection, HK_Close, ADR_Open, Index_Close)
for(i in 1:b){
    Data_Filtered$HK_Close[i] <- HK_TS$`2018.HK.Close`[index(HK_TS) %in% Dateindex_intersection[i]]
    Data_Filtered$ADR_Open[i] <- ADR_TS$AACAY.Open[index(ADR_TS) %in% Dateindex_intersection[i]]
    Data_Filtered$Index_Close[i] <- Index_HK_TS$HSI.Close[index(Index_HK_TS) %in% Dateindex_intersection[i]]
}

#------------------------------------------------------------------------------------------
#Step 3 - Statistical Analysis
source('Analysis_Modules.R')

#Filtered TS for Analysis
Data_Filtered_TS <- as.xts(Data_Filtered[,-1], order.by = Data_Filtered$Dateindex_intersection)

c <- nrow(Data_Filtered_TS) #Total Data Count
d <- c-Test_Days #Training Data count
#Sample data is split into Training set - from 1 to d rows; Test data between d+1 to c rows

#------------------------------------------------------------------------------------------
#Step 3.1.1 - Analysis, Modeling of HK Training Data
HK_Close_LogReturns <- Delt(Data_Filtered_TS$HK_Close[1:d], type = "log")[-1]
Result_HK_Stationarity <- is_Stationary(HK_Close_LogReturns, 1)
Result_HK_Normality <- is_Normal(as.numeric(HK_Close_LogReturns), 1)

ifelse(Result_HK_Stationarity[1] < alpha && Result_HK_Stationarity[2] > alpha, "Time series found to be stationary", "Cross-Check the Data for Stationarity or try other methods")
ifelse(Result_HK_Normality > alpha, "Time series found to be stationary", "Cross-Check the Data for Normality or try other methods")

acf(HK_Close_LogReturns) #Guesstimate the order of MA
pacf(HK_Close_LogReturns) #Guesstimate the order of AR

#Using package for auto identification of ARIMA
#Go for Manual ARIMA order if the acf of Residuals is not satisfactory!
Result_Arima_HK <- auto.arima(HK_Close_LogReturns)
acf(Result_Arima_HK$residuals)

#Trying Manual ARIMA
Manual_Arima_Order <- find_ARIMA_order(HK_Close_LogReturns)
Result_Arima_HK <- arima(HK_Close_LogReturns, order = Manual_Arima_Order)
acf(Result_Arima_HK$residuals)

#Step 3.1.2 - Forecasting HK Data to compare against the Test data (Actuals)
#Forecast using the final of the Manual or Auto Arimas
Forecast_HK_Close_LogReturns <- as.data.frame(forecast(Result_Arima_HK, level = c(70, 95), h = Test_Days))

jpeg(filename = "Forecast_ARIMA_HK.jpeg")
plot(forecast(Result_Arima_HK, h=Test_Days))
dev.off()


jpeg(filename = "Residuals_ARIMA_HK.jpeg")
acf(Result_Arima_HK$residuals)
#If some information left - try different order - or go for GARCH
dev.off()

#------------------------------------------------------------------------------------------
#Step 3.2.1 - Analysis, Modeling of ADR Training Data
#Following exact same steps as earlier for HK

ADR_Open_LogReturns <- Delt(Data_Filtered_TS$ADR_Open[1:d], type = "log")[-1]
Result_ADR_Stationarity <- is_Stationary(ADR_Open_LogReturns, 1)
Result_ADR_Normality <- is_Normal(as.numeric(ADR_Open_LogReturns), 1)

ifelse(Result_HK_Stationarity[1] < alpha && Result_HK_Stationarity[2] > alpha, "Time series found to be stationary", "Cross-Check the Data for Stationarity or try other methods")
ifelse(Result_HK_Normality > alpha, "Time series found to be stationary", "Cross-Check the Data for Normality or try other methods")

acf(ADR_Open_LogReturns) #Guesstimate the order of MA
pacf(ADR_Open_LogReturns) #Guesstimate the order of AR

#Using package for auto identification of ARIMA
#Go for Manual ARIMA order if the acf of Residuals is not satisfactory!
Result_Arima_ADR <- auto.arima(ADR_Open_LogReturns)
acf(Result_Arima_ADR$residuals)
Box.test(Result_Arima_ADR$residuals, lag=20, type="Ljung-Box")



#Trying Manual ARIMA
Manual_Arima_Order <- find_ARIMA_order(ADR_Open_LogReturns)
Result_Arima_ADR <- arima(ADR_Open_LogReturns, order = Manual_Arima_Order)
acf(Result_Arima_ADR$residuals)
Box.test(Result_Arima_ADR$residuals, lag=21, type="Ljung-Box")
#Looks like Manual ARMA is better fitting - so using the Manual ARMA order

#Step 3.2.2 - Forecasting HK Data to compare against the Test data (Actuals)
Forecast_ADR_Open_LogReturns <- as.data.frame(forecast(Result_Arima_ADR, level = c(70, 95), h = Test_Days))

jpeg(filename = "Forecast_ARIMA_ADR.jpeg")
plot(forecast(Result_Arima_ADR, h=Test_Days))
dev.off()

jpeg(filename = "Residuals_ARIMA_ADR.jpeg")
acf(Result_Arima_ADR$residuals)
#If some information left - try different order - or go for GARCH
dev.off()

#------------------------------------------------------------------------------------------
#Step 3.3 - Saving the Forecast data
Data_Forecast <- data.frame(Forecast_HK_Close_LogReturns$`Point Forecast`, Forecast_ADR_Open_LogReturns$`Point Forecast`)
Forecast_HK_ClosePrice <- rep(0, Test_Days)
Forecast_ADR_OpenPrice <- rep(0, Test_Days)

Data_Forecast <- cbind(Data_Forecast, Forecast_HK_ClosePrice, Forecast_ADR_OpenPrice)
colnames(Data_Forecast) <- c("HK_LReturns", "ADR_LReturns", "HK_ForecastPrice", "ADR_ForecastPrice")

Prior_Days <- max(max(Result_Arima_HK$arma), max(Result_Arima_ADR$arma))
#Prior_Days gives an idea of data of how many days prior to the starting datae is used in forecasting

Data_Forecast$HK_ForecastPrice[1] <- exp(Data_Forecast$HK_LReturns[1])*Data_Filtered_TS$HK_Close[d]
Data_Forecast$ADR_ForecastPrice[1] <- exp(Data_Forecast$ADR_LReturns[1])*Data_Filtered_TS$ADR_Open[d]
  
for(i in 2:Test_Days) {
  Data_Forecast$HK_ForecastPrice[i] <- exp(Data_Forecast$HK_LReturns[i])*Data_Forecast$HK_ForecastPrice[i-1]
  Data_Forecast$ADR_ForecastPrice[i] <- exp(Data_Forecast$ADR_LReturns[i])*Data_Forecast$ADR_ForecastPrice[i-1]
}

#------------------------------------------------------------------------------------------
#Step 4 - Evaluating the Statistical Model's power of Forecasting 
#Step 4.1 - Getting the actual data for the test period

Test_HK_LReturns <- Delt(Data_Filtered_TS$HK_Close[d:(b-1)], type = "log")[-1]
Test_ADR_LReturns <- Delt(Data_Filtered_TS$ADR_Open[d:(b-1)], type = "log")[-1]

#In-terms of Prices Forecasted
Data_Graph <- cbind(Data_Filtered_TS$HK_Close[(d+1):b], Data_Forecast$HK_ForecastPrice)
jpeg(filename = "Forecast vs Actual Prices-HK.jpeg")
chart_Series(Data_Graph[,1], type = "lines", name = "Price Movement")
add_TA(Data_Graph[,2], on = 1)
dev.off()

jpeg(filename = "Forecast vs Actual Prices-ADR.jpeg")
Data_Graph <- cbind(Data_Filtered_TS$ADR_Open[(d+1):b], Data_Forecast$ADR_ForecastPrice)
chart_Series(Data_Graph[,1], type = "lines", name = "Price Movement")
add_TA(Data_Graph[,2], on = 1)
dev.off()


#In-terms of Log Returns Forecasted
Data_Graph_1 <- as.xts(Forecast_HK_Close_LogReturns$`Point Forecast`[-1], order.by = index(Test_HK_LReturns))
Data_Graph_2 <- as.xts(Forecast_HK_Close_LogReturns$`Hi 95`[-1], order.by = index(Test_HK_LReturns))
Data_Graph_3 <- as.xts(Forecast_HK_Close_LogReturns$`Lo 95`[-1], order.by = index(Test_HK_LReturns))

jpeg(filename = "Forecast vs Actual LReturns-HK.jpeg")
plot(Test_HK_LReturns, col = "Orange")
lines(Data_Graph_1, col = "Green")
lines(Data_Graph_2, lty = "dashed", col = "Blue")
lines(Data_Graph_3, lty = "dashed", col = "Blue")
dev.off()

Data_Graph_1 <- as.xts(Forecast_ADR_Open_LogReturns$`Point Forecast`[-1], order.by = index(Test_ADR_LReturns))
Data_Graph_2 <- as.xts(Forecast_ADR_Open_LogReturns$`Hi 95`[-1], order.by = index(Test_ADR_LReturns))
Data_Graph_3 <- as.xts(Forecast_ADR_Open_LogReturns$`Lo 95`[-1], order.by = index(Test_ADR_LReturns))

jpeg(filename = "Forecast vs Actual LReturns-ADR.jpeg")
plot(Test_ADR_LReturns, col = "Orange")
lines(Data_Graph_1, col = "Blue")
lines(Data_Graph_2, lty = "dashed", col = "Red")
lines(Data_Graph_3, lty = "dashed", col = "Red")
dev.off()

#------------------------------------------------------------------------------------------
#Step 5 - Fundamental Analysis (Based on Idiosyncracies of the particular firm)
#5.1 - Preliminary Filtering of the available Data

Index_Close_LogReturns <- Delt(Data_Filtered_TS$Index_Close[1:d], type = "log")[-1]
jpeg(filename = "LogReturns Movement - HK vs Index.jpeg")
chart_Series(HK_Close_LogReturns, type = "lines", name = "LogReturns Movement")
add_TA(Index_Close_LogReturns)
dev.off()

jpeg(filename = "LogReturns Movement - HK vs ADR.jpeg")
chart_Series(HK_Close_LogReturns, type = "lines", name = "LogReturns Movement")
add_TA(ADR_Open_LogReturns)
dev.off()

jpeg(filename = "All 3 TS LogReturns Superimposed.jpeg")
plot(ADR_Open_LogReturns, col = "blue")
points(HK_Close_LogReturns, col = "yellow")
lines(Index_Close_LogReturns, col = "red")
dev.off()

#Filtering the data based on Excess Returns in HK Market
#Excess Returns defined as Logreturns on the HK asset over and above the Logreturns on Index
HK_ExcessReturns <- rep(0,d-1)
HK_ExcessReturns <- HK_Close_LogReturns - Index_Close_LogReturns

jpeg(filename = "Excess Returns in HK.jpeg")
plot(Index_Close_LogReturns, col = "blue")
lines(HK_ExcessReturns, col = "red")
dev.off()

data_LogReturns <- data.frame(HK_Close_LogReturns, ADR_Open_LogReturns, Index_Close_LogReturns, HK_ExcessReturns)
colnames(data_LogReturns) <- c("HK_LReturns", "ADR_LReturns", "Index_LReturns", "HK_ExcessReturns")
nrow(data_LogReturns)

#At least 2% More/ Less than the HK Market Index
data_LogReturns <- data_LogReturns[data_LogReturns[4] > 0.02 | data_LogReturns[4] < -0.02, ]
nrow(data_LogReturns)

#At least a movement of 1 basis point in ADR (in-order to effect a trade)
data_LogReturns <- data_LogReturns[data_LogReturns[2] > 0.0001 | data_LogReturns[2] < -0.0001, ]
nrow(data_LogReturns)

jpeg(filename = "Idiosyncratic Relationship.jpeg")
plot(as.numeric(data_LogReturns$HK_LReturns), as.numeric(data_LogReturns$ADR_LReturns), type = "p")
dev.off()

jpeg(filename = "Beta Relationship.jpeg")
plot(as.numeric(data_LogReturns$HK_LReturns), as.numeric(data_LogReturns$Index_LReturns), type = "p")
dev.off()

Final_Correlation_Idio <- cor(data_LogReturns$HK_LReturns, data_LogReturns$ADR_LReturns)
Final_Correlation_Beta <- cor(data_LogReturns$HK_LReturns, data_LogReturns$Index_LReturns)


#------------------------------------------------------------------------------------------
#Taking the Final_Correlation Idio & Beta as the inputs, Trading Strategy is implemented
#5.2 - Implementing Trading Strategy on the Filtered Data - Specific to this stock

Trade_Data_TS <- Data_Filtered_TS[d:c, ]
nrow(Trade_Data_TS)
Trade_HK_LReturns <- Delt(Trade_Data_TS$HK_Close, type = "log")[-1]
Trade_ADR_LReturns <- Delt(Trade_Data_TS$ADR_Open, type = "log")[-1]
Trade_Index_LReturns <- Delt(Trade_Data_TS$Index_Close, type = "log")[-1]

Trade_Data_TS <- cbind(Trade_Data_TS, Trade_HK_LReturns, Trade_ADR_LReturns, Trade_Index_LReturns)
colnames(Trade_Data_TS)[4:6] <- c("HK_LReturns", "ADR_LReturns", "Index_LReturns")
Trade_Data_TS <- Trade_Data_TS[-1,]

Trade_ADR_ForecastReturns <- Data_Forecast$ADR_LReturns

Trade_Data_TS <- cbind(Trade_Data_TS, Trade_ADR_ForecastReturns)
colnames(Trade_Data_TS)[7] <- c("ADR_F_LReturns")

#Note on the Trading Strategy - Mimicing the movement on HK Market

#Principle 1 - on When to Buy/ Sell (initiate a trade)
#If HK Close moved more than +2% (relative to it's Index) - Buy ADR
#If HK Close moved more than -2% (relative to it's Index) - Sell ADR

#Principle 2 - on how much to Buy/ Sell
#Based on the Magnitude of Movements w.r.t the HK Mkt Index
#For Buying:
#2-5% movement - Increase the holdings by investing 2% of your Excess Cash
#5-10% movement - Increase the holdings by investing 5% of your Excess Cash
#10-25% movement - Increase the holdings by investing 10% of your Excess Cash
#25-50% movement - Increase the holdings by investing 20% of your Excess Cash
#>50% movement - Increase the holdings by investing 25% of your Excess Cash

#For Selling:
#2-5% movement - Decrease the holdings by 20%
#5-10% movement - Decrease the holdings by 40%
#10-25% movement - Decrease the holdings by 60%
#25-50% movement - Decrease the holdings by 80%
#>50% movement - Decrease the holdings by 100%

Trade_Criteria_1 <- Trade_Data_TS$HK_LReturns - Trade_Data_TS$Index_LReturns
dummy_Criteria_1 <- ifelse(Trade_Criteria_1 > 0.02, 1, ifelse(Trade_Criteria_1 < -0.02, 2, 0))
dummy_Criteria_2 <- ifelse(Trade_Criteria_1 > 0.02 & Trade_Data_TS$ADR_F_LReturns > 0, 1, ifelse(Trade_Criteria_1 < -0.02 & Trade_Data_TS$ADR_F_LReturns < 0, 2, 0))

Trade_Data_TS <- cbind(Trade_Data_TS, Trade_Criteria_1, dummy_Criteria_1, dummy_Criteria_2)
colnames(Trade_Data_TS)[8:10] <- c("Criteria_1", "dummy_C1", "dummy_C2")


#Following Strategy 1
Portfolio_Current_1 <- 0
Excess_Cash_1 <- 10000
Current_Order_1 <- 0
Nett_Holdings_1 <- rep(Portfolio_Current_1, Test_Days) 
Nett_Cash_1 <- rep(Excess_Cash_1, Test_Days)
Nett_Wealth_1 <- rep(Excess_Cash_1+Portfolio_Current_1*1, Test_Days)

for(i in 1:Test_Days) {
  #Executing Buy Order
  if(Trade_Data_TS$dummy_C1[i] == 1) {
    if(Trade_Data_TS$Criteria_1[i] < 0.05) {
      Current_Order_1 <- as.numeric(floor((Excess_Cash_1*0.02)/Trade_Data_TS$ADR_Open[i]))
    } else if(Trade_Data_TS$Criteria_1[i] < 0.10) {
      Current_Order_1 <- as.numeric(floor((Excess_Cash_1*0.05)/Trade_Data_TS$ADR_Open[i]))
    } else if(Trade_Data_TS$Criteria_1[i] < 0.25) {
      Current_Order_1 <- as.numeric(floor((Excess_Cash_1*0.10)/Trade_Data_TS$ADR_Open[i]))
    } else if(Trade_Data_TS$Criteria_1[i] < 0.5) {
      Current_Order_1 <- as.numeric(floor((Excess_Cash_1*0.20)/Trade_Data_TS$ADR_Open[i]))
    } else {
      Current_Order_1 <- as.numeric(floor((Excess_Cash_1*0.25)/Trade_Data_TS$ADR_Open[i]))
    }
    
    Excess_Cash_1 <- as.numeric(Excess_Cash_1 - (Current_Order_1*Trade_Data_TS$ADR_Open[i]))
    Portfolio_Current_1 <- as.numeric(Portfolio_Current_1 + Current_Order_1)
  }
  
  #Executing Sell Order
  if(Trade_Data_TS$dummy_C1[i] == 2) {
    if(Trade_Data_TS$Criteria_1[i] > -0.05) {
      Current_Order_1 <- as.numeric(ceiling(Portfolio_Current_1*0.20))
    } else if(Trade_Data_TS$Criteria_1[i] > -0.10) {
      Current_Order_1 <- as.numeric(ceiling(Portfolio_Current_1*0.40))
    } else if(Trade_Data_TS$Criteria_1[i] > -0.25) {
      Current_Order_1 <- as.numeric(ceiling(Portfolio_Current_1*0.60))
    } else if(Trade_Data_TS$Criteria_1[i] > -0.50) {
      Current_Order_1 <- as.numeric(ceiling(Portfolio_Current_1*0.80))
    } else {
      Current_Order_1 <- as.numeric(Portfolio_Current_1)
    }
    
    Excess_Cash_1 <- as.numeric(Excess_Cash_1 + (Current_Order_1*Trade_Data_TS$ADR_Open[i]))
    Portfolio_Current_1 <- as.numeric(Portfolio_Current_1 - Current_Order_1)
  }
  
  Nett_Holdings_1[i] <- as.numeric(Portfolio_Current_1)
  Nett_Cash_1[i] <- as.numeric(Excess_Cash_1)
  Nett_Wealth_1[i] <- as.numeric(Nett_Cash_1[i] + (Nett_Holdings_1[i]*Trade_Data_TS$ADR_Open[i]))
}


#Following Strategy 2
Portfolio_Current_2 <- 0
Excess_Cash_2 <- 10000
Current_Order_2 <- 0
Nett_Holdings_2 <- rep(Portfolio_Current_2, Test_Days) 
Nett_Cash_2 <- rep(Excess_Cash_2, Test_Days)
Nett_Wealth_2 <- rep(Excess_Cash_2+Portfolio_Current_2*1, Test_Days)


for(i in 1:Test_Days) {
  #Executing Buy Order
  if(Trade_Data_TS$dummy_C2[i] == 1) {
    if(Trade_Data_TS$Criteria_1[i] < 0.05) {
      Current_Order_2 <- as.numeric(floor((Excess_Cash_2*0.05)/Trade_Data_TS$ADR_Open[i]))
    } else if(Trade_Data_TS$Criteria_1[i] < 0.10) {
      Current_Order_2 <- as.numeric(floor((Excess_Cash_2*0.10)/Trade_Data_TS$ADR_Open[i]))
    } else if(Trade_Data_TS$Criteria_1[i] < 0.25) {
      Current_Order_2 <- as.numeric(floor((Excess_Cash_2*0.20)/Trade_Data_TS$ADR_Open[i]))
    } else if(Trade_Data_TS$Criteria_1[i] < 0.5) {
      Current_Order_2 <- as.numeric(floor((Excess_Cash_2*0.33)/Trade_Data_TS$ADR_Open[i]))
    } else {
      Current_Order_2 <- as.numeric(floor((Excess_Cash_2*0.66)/Trade_Data_TS$ADR_Open[i]))
    }
    
    Excess_Cash_2 <- as.numeric(Excess_Cash_2 - (Current_Order_2*Trade_Data_TS$ADR_Open[i]))
    Portfolio_Current_2 <- as.numeric(Portfolio_Current_2 + Current_Order_2)
  }
  
  #Executing Sell Order
  if(Trade_Data_TS$dummy_C2[i] == 2) {
    if(Trade_Data_TS$Criteria_1[i] > -0.05) {
      Current_Order_2 <- as.numeric(ceiling(Portfolio_Current_2*0.25))
    } else if(Trade_Data_TS$Criteria_1[i] > -0.10) {
      Current_Order_2 <- as.numeric(ceiling(Portfolio_Current_2*0.50))
    } else if(Trade_Data_TS$Criteria_1[i] > -0.25) {
      Current_Order_2 <- as.numeric(ceiling(Portfolio_Current_2*0.75))
    } else if(Trade_Data_TS$Criteria_1[i] > -0.50) {
      Current_Order_2 <- as.numeric(ceiling(Portfolio_Current_2*0.90))
    } else {
      Current_Order_2 <- as.numeric(Portfolio_Current_2)
    }
    
    Excess_Cash_2 <- as.numeric(Excess_Cash_1 + (Current_Order_2*Trade_Data_TS$ADR_Open[i]))
    Portfolio_Current_2 <- as.numeric(Portfolio_Current_2 - Current_Order_2)
  }
  
  Nett_Holdings_2[i] <- as.numeric(Portfolio_Current_2)
  Nett_Cash_2[i] <- as.numeric(Excess_Cash_2)
  Nett_Wealth_2[i] <- as.numeric(Nett_Cash_2[i] + (Nett_Holdings_2[i]*Trade_Data_TS$ADR_Open[i]))
}

jpeg(filename = "Nett Wealth Movement - Strategy 1.jpeg")
plot(Nett_Wealth_1, type = "l", col = "orange")
lines(Nett_Wealth_1, col = "green")
dev.off()

jpeg(filename = "Nett Wealth Movement - Strategy 2.jpeg")
plot(Nett_Wealth_2, type = "l", col = "blue")
dev.off()


jpeg(filename = "Nett Wealth Movement - Strategy 1 & 2.jpeg")
plot(Nett_Wealth_2, type = "l", col = "blue", ylim = c(min(Nett_Wealth_2), max(Nett_Wealth_2)))
lines(Nett_Wealth_1, col = "orange")
dev.off()

#------------------------------------------------------------------------------------------
#Check and Save the Results!!
Final_Correlation_Beta
Final_Correlation_Idio
Result_Arima_ADR$arma
Result_Arima_HK$arma
N_Trades_1 <- sum(Trade_Data_TS$dummy_C1 == 2) + sum(Trade_Data_TS$dummy_C1 == 1)
N_Trades_2 <- sum(Trade_Data_TS$dummy_C2 == 2) + sum(Trade_Data_TS$dummy_C2 == 1)
Data_Usage <- nrow(data_LogReturns)/nrow(ADR_TS)

Output_Data_1 <- table(Final_Correlation_Beta, Final_Correlation_Idio, Result_Arima_HK$arma[1], Result_Arima_HK$arma[2], Result_Arima_ADR$arma[1], Result_Arima_ADR$arma[2], N_Trades_1, N_Trades_2, Data_Usage)
write.csv(Output_Data_1, file = "Output Data_1.csv")
Output_Data_2 <- cbind(Nett_Wealth_1, Nett_Wealth_2)
write.csv(Output_Data_2, file = "Output Data_2.csv")

#5.3 - Implementing Trading Strategy on a portfolio of ADRs